package org.openmrs.module.orderentryui;

import org.junit.Test;
import org.openmrs.test.BaseModuleContextSensitiveTest;

import static org.junit.Assert.assertTrue;

public class OrderEntryUiActivatorTest extends BaseModuleContextSensitiveTest {

    @Test
    public void testContext() throws Exception {
        assertTrue(true);
    }
}