package org.openmrs.module.htmlformentry.util;

public enum MatchMode {
	START,
	ANYWHERE,
	END;
}
