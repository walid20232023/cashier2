package org.openmrs.module.htmlformentry.util;

public interface Predicate<T> {
	
	boolean test(T t);
}
