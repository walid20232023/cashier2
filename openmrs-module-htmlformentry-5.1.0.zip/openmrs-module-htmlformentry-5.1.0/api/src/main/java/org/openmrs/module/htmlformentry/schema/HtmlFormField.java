package org.openmrs.module.htmlformentry.schema;

/**
 * Standard interface for a field in a HTML Form schema
 */
public interface HtmlFormField {
	
}
