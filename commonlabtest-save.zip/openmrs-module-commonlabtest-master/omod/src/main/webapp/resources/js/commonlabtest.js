// Common Javascript functions
