/**
 * This Source Code Form is subject to the terms of the Mozilla Public License,
 * v. 2.0. If a copy of the MPL was not distributed with this file, You can
 * obtain one at http://mozilla.org/MPL/2.0/. OpenMRS is also distributed under
 * the terms of the Healthcare Disclaimer located at http://openmrs.org/license.
 *
 * Copyright (C) OpenMRS Inc. OpenMRS is a registered trademark and the OpenMRS
 * graphic logo is a trademark of OpenMRS Inc.
 */
package org.openmrs.module.commonlabtest.aop.common;

import org.openmrs.api.OpenmrsService;
import org.springframework.aop.AfterReturningAdvice;

/**
 * @author tahira.niazi@ihsinformatics.com
 */
public interface TestAOP {

	/**
	 * Sets an AOP advice class to be active on the test case.
	 * 
	 * @param afterAdviceClass
	 */
	void setAspect(Class<? extends AfterReturningAdvice> afterAdviceClass);

	/**
	 * Sets an AOP advice class to be active on the test case.
	 * 
	 * @param afterAdvice
	 */
	void setAspect(AfterReturningAdvice afterAdvice);

	/**
	 * Hooks the OpenMRS Services
	 * 
	 * @param serviceClass
	 */
	void addService(Class<? extends OpenmrsService> serviceClass);

}
