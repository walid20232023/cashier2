module.exports = {
    parser: 'flow',
    printWidth: 120,
    singleQuote: true,
    tabWidth: 4,
    useTabs: false,
    semi: true,
    singleQuote: true,
    trailingComma: 'none',
    bracketSpacing: false,
    jsxBracketSameLine: true,
    arrowParens: 'always'
};