Object.defineProperties(window.location, {
    host: {
        writable: true,
        value: '192.168.33.10'
    },
    hostname: {
        writable: true,
        value: '192.168.33.10'
    },
    href: {
        writable: true,
        value: 'https://192.168.33.10/openmrs/owa/bedmanagement/admissionLocations.html'
    },
    origin: {
        writable: true,
        value: 'https://192.168.33.10'
    },
    pathname: {
        writable: true,
        value: '/openmrs/owa/bedmanagement/admissionLocations.html'
    },
    port: {
        writable: true,
        value: ''
    },
    protocol: {
        writable: true,
        value: 'https:'
    }
});
