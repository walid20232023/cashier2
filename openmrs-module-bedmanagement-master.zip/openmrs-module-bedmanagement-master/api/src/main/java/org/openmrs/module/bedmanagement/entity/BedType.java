package org.openmrs.module.bedmanagement.entity;

import org.openmrs.BaseOpenmrsMetadata;

public class BedType extends BaseOpenmrsMetadata {
	
	private Integer id;
	
	private String name;
	
	private String displayName;
	
	private String description;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
}
