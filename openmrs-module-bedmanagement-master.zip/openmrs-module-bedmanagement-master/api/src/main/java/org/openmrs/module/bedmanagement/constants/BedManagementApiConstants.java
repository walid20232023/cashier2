package org.openmrs.module.bedmanagement.constants;

public class BedManagementApiConstants {
	
	public static final String LOCATION_TAG_SUPPORTS_ADMISSION = "Admission Location";
}
