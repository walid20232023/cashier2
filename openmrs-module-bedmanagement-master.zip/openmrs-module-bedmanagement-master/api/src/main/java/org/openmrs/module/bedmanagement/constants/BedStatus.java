package org.openmrs.module.bedmanagement.constants;

public enum BedStatus {
	AVAILABLE,
	OCCUPIED
}
