openmrs-module-simplelabentry
=============================

Provides basic support for entering lab test orders and recording results
