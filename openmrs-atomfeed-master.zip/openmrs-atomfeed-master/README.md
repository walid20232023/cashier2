openmrs-atomfeed-publisher
==========================

[![Build Status](https://travis-ci.org/ICT4H/openmrs-atomfeed-publisher.png)](https://travis-ci.org/ICT4H/openmrs-atomfeed-publisher)

AtomFeed Module For OpenMrs.


Dependencies
===========================

This uses [the atomfeed module](https://github.com/ICT4H/atomfeed) to publish events.
