export default {
  location: {
    href: 'http://localhost:3000/openmrs-standalone/owa/openmrs-owa-orderentry/index.html',
  },
};
