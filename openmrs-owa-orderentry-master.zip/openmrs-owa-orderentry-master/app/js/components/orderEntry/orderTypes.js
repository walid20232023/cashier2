export const DRUG_ORDER = { id: 1, text: 'Drug Orders' };
export const LAB_ORDER = { id: 2, text: 'Lab Orders' };
