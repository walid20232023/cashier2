### **JIRA TICKET NAME**
[OEUI-1234](https://mocklink) mock text

### **Summary**
- sample summary

## I have checked that on this Pull request

- [ ] I can sucessfully create Drug orders
- [ ] I can sucessfully create Lab orders
- [ ] I can sucessfully search for drug orders
